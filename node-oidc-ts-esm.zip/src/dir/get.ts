const get = () => {
  console.log('Hello world');
  return 4;
};

export default get;
