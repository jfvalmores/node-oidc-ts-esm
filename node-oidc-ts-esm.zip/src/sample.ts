const test = () => {
  console.log('Working!');
  return 3;
};

export default test;
